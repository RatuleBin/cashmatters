from django.conf import settings
from django.urls import include, path
from django.contrib import admin
from django.contrib.admin.views.decorators import staff_member_required
from django.http import HttpResponse
from django.shortcuts import render, redirect
import os

from wagtail.admin import urls as wagtailadmin_urls
from wagtail import urls as wagtail_urls
from wagtail.documents import urls as wagtaildocs_urls

from search import views as search_views
from blog.api import api_router

# Frontend views
def index(request):
    """Serve the homepage"""
    return render(request, 'index.html')


def news(request):
    """Serve the news page with dynamic articles"""
    from blog.models import ArticlePage
    
    # Get all published articles ordered by date (newest first)
    articles = ArticlePage.objects.live().order_by('-date')
    
    # Debug: Print articles and dates
    print(f"DEBUG: Total articles: {articles.count()}")
    for article in articles[:5]:
        print(f"DEBUG: {article.title} - Date: {article.date}")
    
    context = {
        'articles': articles,
    }
    return render(request, 'news.html', context)


def support(request):
    """Serve the support page"""
    return render(request, 'support.html')


def why_cash(request):
    """Serve the why cash page"""
    return render(request, 'why-cash.html')


def blogs_dashboard_redirect(request):
    """Redirect old blogs URL to new admin location"""
    return redirect('/admin/all-blogs/')


def create_blog_page(request):
    """Redirect to Wagtail admin for creating blog posts with clean URL"""
    from blog.models import BlogIndexPage
    from django.http import HttpResponsePermanentRedirect

    try:
        # Get the first BlogIndexPage
        # (assuming there's only one main blog index)
        blog_index = BlogIndexPage.objects.live().first()
        if blog_index:
            url = f'/admin/pages/add/blog/blogpage/{blog_index.id}/'
            return HttpResponsePermanentRedirect(url)
        else:
            # Fallback to hardcoded ID if no BlogIndexPage found
            return HttpResponsePermanentRedirect(
                '/admin/pages/add/blog/blogpage/6/')
    except Exception:
        # Fallback to hardcoded ID if there's any error
        return HttpResponsePermanentRedirect(
            '/admin/pages/add/blog/blogpage/6/')


@staff_member_required
def blogs_dashboard(request):
    """Blog management dashboard"""
    from blog.models import ArticlePage
    from django.db.models import Q
    from django.core.paginator import Paginator
    from django.contrib import messages
    from django.shortcuts import redirect

    # Handle bulk actions
    if request.method == 'POST':
        selected_posts = request.POST.getlist('selected_posts')
        bulk_action = request.POST.get('bulk_action')
        
        if selected_posts and bulk_action:
            posts = ArticlePage.objects.filter(id__in=selected_posts)
            
            if bulk_action == 'publish':
                for post in posts:
                    if not post.live:
                        post.save_revision().publish()
                messages.success(
                    request, f"Published {len(selected_posts)} post(s)."
                )
            elif bulk_action == 'unpublish':
                for post in posts:
                    if post.live:
                        post.unpublish()
                messages.success(
                    request, f"Unpublished {len(selected_posts)} post(s)."
                )
            elif bulk_action == 'delete':
                count = posts.count()
                posts.delete()
                messages.success(request, f"Deleted {count} post(s).")
            
            return redirect(request.get_full_path())
    
    # Get search query
    search_query = request.GET.get('q', '')
    
    # Get filter parameters
    category_filter = request.GET.get('category', '')
    status_filter = request.GET.get('status', '')
    location_filter = request.GET.get('location', '')
    sector_filter = request.GET.get('sector', '')
    
    # Base queryset - all article pages
    blog_posts = ArticlePage.objects.all().order_by('-date')
    
    # Apply search filter
    if search_query:
        blog_posts = blog_posts.filter(
            Q(title__icontains=search_query) |
            Q(intro__icontains=search_query) |
            Q(body__icontains=search_query)
        )
    
    # Apply category filter
    if category_filter:
        blog_posts = blog_posts.filter(article_types__name=category_filter)
    
    # Apply status filter
    if status_filter == 'live':
        blog_posts = blog_posts.filter(live=True)
    elif status_filter == 'draft':
        blog_posts = blog_posts.filter(live=False)
    
    # Apply location filter
    if location_filter:
        blog_posts = blog_posts.filter(locations__name=location_filter)
    
    # Apply sector filter
    if sector_filter:
        blog_posts = blog_posts.filter(sectors__name=sector_filter)
    
    # Remove duplicates from many-to-many filters
    blog_posts = blog_posts.distinct()
    
    # Pagination
    paginator = Paginator(blog_posts, 20)  # 20 posts per page
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    # Get unique values for filters
    categories = ArticlePage.objects.values_list(
        'article_types__name', flat=True
    ).distinct().exclude(article_types__name__isnull=True)
    locations = ArticlePage.objects.values_list(
        'locations__name', flat=True
    ).distinct().exclude(locations__name__isnull=True)
    sectors = ArticlePage.objects.values_list(
        'sectors__name', flat=True
    ).distinct().exclude(sectors__name__isnull=True)
    
    # Stats
    total_posts = ArticlePage.objects.count()
    live_posts = ArticlePage.objects.filter(live=True).count()
    draft_posts = ArticlePage.objects.filter(live=False).count()

    context = {
        'blog_posts': page_obj,
        'search_query': search_query,
        'category_filter': category_filter,
        'status_filter': status_filter,
        'location_filter': location_filter,
        'sector_filter': sector_filter,
        'categories': sorted(set(categories)),
        'locations': sorted(set(locations)),
        'sectors': sorted(set(sectors)),
        'total_posts': total_posts,
        'live_posts': live_posts,
        'draft_posts': draft_posts,
        'paginator': paginator,
        'page_obj': page_obj,
    }
    return render(request, 'blogs_dashboard.html', context)


urlpatterns = [
    path("", index, name="index"),  # Root URL serves the homepage
    path("news/", news, name="news"),  # News page
    path("support/", support, name="support"),  # Support page
    path("why-cash/", why_cash, name="why_cash"),  # Why cash page
    path("django-admin/", admin.site.urls),
    path("admin/all-blogs/", blogs_dashboard, name="blogs_dashboard_custom"),
    path("admin/pages/add/blog/blogpage/", create_blog_page,
         name="create_blog_page"),
    path("admin/", include(wagtailadmin_urls)),
    path("admin/blogs/add/", blogs_dashboard, name="blogs_dashboard"),
    # Blog creation dashboard
    path("blogs/add/", blogs_dashboard_redirect,
         name="blogs_dashboard_redirect"),  # Redirect old URL
    path("documents/", include(wagtaildocs_urls)),
    path("api/v2/", api_router.urls),
    path("search/", search_views.search, name="search"),
    path("blog/", include("blog.urls")),  # Blog app URLs
]


if settings.DEBUG:
    from django.conf.urls.static import static
    from django.contrib.staticfiles.urls import staticfiles_urlpatterns

    # Serve static and media files from development server
    urlpatterns += staticfiles_urlpatterns()
    urlpatterns += static(
        settings.MEDIA_URL, document_root=settings.MEDIA_ROOT
    )

urlpatterns = urlpatterns + [
    # For anything not caught by a more specific rule above, hand over to
    # Wagtail's page serving mechanism. This should be the last pattern in
    # the list:
    path("", include(wagtail_urls)),
    # Alternatively, if you want Wagtail pages to be served from a subpath
    # of your site, rather than the site root:
    #    path("pages/", include(wagtail_urls)),
]
